package com.sap.refapps.companylist.main;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.eclipse.persistence.jpa.jpql.parser.DateTime;

@Entity
public class AirDevice {
	
	public AirDevice() {
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;
	int device;
	double co_value;
	double o3_value;
	double so2_value;
	double no2_value;
	double temperature_value;
	double humidity_value;
	double pressure_value;
	double pm10_value;
	double pm25_value;
	double pm1_value;
	double battery_value;
	String pub_time;
	String pub_date;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getDevice() {
		return device;
	}
	public void setDevice(int device) {
		this.device = device;
	}
	public double getCo_value() {
		return co_value;
	}
	public void setCo_value(double co_value) {
		this.co_value = co_value;
	}
	public double getO3_value() {
		return o3_value;
	}
	public void setO3_value(double o3_value) {
		this.o3_value = o3_value;
	}
	public double getSo2_value() {
		return so2_value;
	}
	public void setSo2_value(double so2_value) {
		this.so2_value = so2_value;
	}
	public double getNo2_value() {
		return no2_value;
	}
	public void setNo2_value(double no2_value) {
		this.no2_value = no2_value;
	}
	public double getTemperature_value() {
		return temperature_value;
	}
	public void setTemperature_value(double temperature_value) {
		this.temperature_value = temperature_value;
	}
	public double getHumidity_value() {
		return humidity_value;
	}
	public void setHumidity_value(double humidity_value) {
		this.humidity_value = humidity_value;
	}
	public double getPressure_value() {
		return pressure_value;
	}
	public void setPressure_value(double pressure_value) {
		this.pressure_value = pressure_value;
	}
	public double getPm10_value() {
		return pm10_value;
	}
	public void setPm10_value(double pm10_value) {
		this.pm10_value = pm10_value;
	}
	public double getPm25_value() {
		return pm25_value;
	}
	public void setPm25_value(double pm25_value) {
		this.pm25_value = pm25_value;
	}
	public double getPm1_value() {
		return pm1_value;
	}
	public void setPm1_value(double pm1_value) {
		this.pm1_value = pm1_value;
	}
	public double getBattery_value() {
		return battery_value;
	}
	public void setBattery_value(double battery_value) {
		this.battery_value = battery_value;
	}
	public String getPub_time() {
		return pub_time;
	}
	public void setPub_time(String pub_time) {
		this.pub_time = pub_time;
	}
	public String getPub_date() {
		return pub_date;
	}
	public void setPub_date(String pub_date) {
		this.pub_date = pub_date;
	}
	
}
