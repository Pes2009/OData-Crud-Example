package com.sap.refapps.companylist.main;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.refapps.companylist.main.AirDevice;
import com.sap.refapps.companylist.util.DataLoader;
import com.sap.refapps.companylist.util.Utility;


/**
 * Servlet implementation class PersistenceWithJPAServlet
 * Servlet for creating the Persistence Service and the related EnitityManagerFactory instance
 */
public class PersistenceWithJPAServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory
			.getLogger(PersistenceWithJPAServlet.class);


	private DataSource ds;
	private static EntityManagerFactory emf = null;
	private DataLoader datLoader;

	/**
	 * (non-Javadoc)
	 * @see javax.servlet.GenericServlet#init()
	 * creating the EntityManagerFactory
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void init() throws ServletException {

	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		  List<String> someList = new ArrayList<String>();
		    StringBuilder stringBuilder = new StringBuilder(1000);
		    Scanner scanner = new Scanner(request.getInputStream());
		    while (scanner.hasNextLine()) {
		        stringBuilder.append(scanner.nextLine());
//		        someList.add(scanner.nextLine());
		    }
//		    String body = someList.toString();
		    String body = stringBuilder.toString();
		    String[] nameValuePairs = body.split("&");
		    List<String> airParametrsList = new ArrayList<String>();
		    
		    for(String nameValuePair: nameValuePairs) {
//		    	nameValuePair.replaceAll("[a-z,A-Z,0-9]{1,}[=]{1}", "");
//		    	response.getWriter().println(nameValuePair);
//		    	response.getWriter().println(nameValuePair);
		    	String[] names = nameValuePair.split("=");
		    	 for(String x: names) {
		    		 airParametrsList.add(x);
		    	response.getWriter().println(x);
		    	 }
		    	}  
		    response.getWriter().println(airParametrsList);
		Connection connection = null;
		try {
			InitialContext ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/DefaultDB");
			connection = ds.getConnection();
			Map properties = new HashMap();
			properties.put(PersistenceUnitProperties.NON_JTA_DATASOURCE, ds);

			emf = Persistence.createEntityManagerFactory("refapp-companylist-web", properties);

			Utility.setEntityManagerFactory(emf);
			datLoader = new DataLoader();
			//datLoader.loadData();
			 AirDevice airDevice = new AirDevice();
			    airDevice.setDevice(1);
			    airDevice.setCo_value(3.0446);
			    airDevice.setO3_value(0.0000);		    
			    airDevice.setSo2_value(0.1721);		    
			    airDevice.setNo2_value(0.0000);
			    airDevice.setTemperature_value(21.57);		    
			    airDevice.setHumidity_value(55.2891);
			    airDevice.setPressure_value(990.9634);		    
			    airDevice.setPm10_value(3.1000);		    
			    airDevice.setPm25_value(3.0400);
			    airDevice.setPm1_value(2.5000);		    		    
			    airDevice.setBattery_value(88.00);
			    
			    response.getWriter().println(airDevice);
			    datLoader.addAirDevice(airDevice);

		} catch (NamingException e) {
			throw new ServletException(e);
		} catch (SQLException e) {
			LOGGER.error("Could not determine database product.");
			throw new ServletException(e);
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException x) {
					LOGGER.debug("Unable to close connection.", x);
				}
			}
		}
		
	}



	/** {@inheritDoc} */
	@Override
	public void destroy() {
		emf.close();
	}

}
